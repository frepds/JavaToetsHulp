// code voor opgave 1
//
import java.util.ArrayList;

public class Koffer {

	public int grootte;
	public String inhoud;
	public int code;

	// voor vraag $REF::@TRY_CATCH$
	public ArrayList<Koffer> verdeel(int aantal, String naam) {
		int nieuweGrootte = 1 + grootte / aantal;
		ArrayList<Koffer> lijstje = new ArrayList<>();
		for (int i = 0; i < aantal; i++) {
			String nieuweInhoud = inhoud + "_"
					+ naam.toLowerCase() + "#" + (i + 1);
			lijstje.add(new Koffer(nieuweGrootte, nieuweInhoud));
		}
		return lijstje;
	}
}
