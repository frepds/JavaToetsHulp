// code voor opgave 2
//
public class Station {

	private int id;
	private String naam;

	public Station(int i, String n) {
		id = i;
		naam = n;
	}

	public String toString() { return naam; }
}
