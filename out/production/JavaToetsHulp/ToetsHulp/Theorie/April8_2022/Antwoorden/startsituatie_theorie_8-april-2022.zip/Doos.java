// code voor opgave 1
//
public class Doos {

	private String inhoud;

	public Doos(String i) { inhoud = i; }

	public String toString() { return inhoud; }
}
