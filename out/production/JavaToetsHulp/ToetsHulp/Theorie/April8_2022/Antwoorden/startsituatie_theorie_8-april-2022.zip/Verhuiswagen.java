// code voor opgave 1
//
public class Verhuiswagen {

	public Verhuiswagen(int lengte) { /*...todo...*/ }

	public void print() { /*...todo...*/ }

	public boolean zetNeer(Doos doos, int plek) {
		// ...todo...
		return false;
	}

	public int zetOpLaatsteVrijePlek(Doos doos) {
		// ...todo...
		return 0;
	}
}
